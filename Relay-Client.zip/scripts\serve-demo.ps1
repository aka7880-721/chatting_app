# Serves the production build (dist/) for client demos — no Node.js required.
$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path $PSScriptRoot -Parent
$root = Join-Path $projectRoot 'dist'
if (-not (Test-Path $root)) {
    Write-Host ''
    Write-Host 'ERROR: dist folder is missing. Ask your developer to run: npm run build'
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 1
}
$root = (Resolve-Path $root).Path

if (-not (Test-Path (Join-Path $root 'index.html'))) {
    Write-Host ''
    Write-Host 'ERROR: dist folder is missing. Ask your developer to run: npm run build'
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 1
}

$port = 4173
$hostName = '127.0.0.1'
$prefix = "http://${hostName}:$port/"

$mimes = @{
    '.html' = 'text/html; charset=utf-8'
    '.js'   = 'application/javascript; charset=utf-8'
    '.css'  = 'text/css; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'
    '.svg'  = 'image/svg+xml'
    '.png'  = 'image/png'
    '.jpg'  = 'image/jpeg'
    '.webp' = 'image/webp'
    '.ico'  = 'image/x-icon'
    '.woff' = 'font/woff'
    '.woff2'= 'font/woff2'
}

function Get-LocalPath($rawUrl) {
    $path = [System.Uri]::UnescapeDataString($rawUrl.LocalPath.TrimStart('/'))
    if ([string]::IsNullOrWhiteSpace($path)) { return Join-Path $root 'index.html' }
    $candidate = Join-Path $root ($path -replace '/', [IO.Path]::DirectorySeparatorChar)
    $fullRoot = [IO.Path]::GetFullPath($root)
    $fullCandidate = [IO.Path]::GetFullPath($candidate)
    if (-not $fullCandidate.StartsWith($fullRoot, [StringComparison]::OrdinalIgnoreCase)) {
        return Join-Path $root 'index.html'
    }
    if (Test-Path $fullCandidate -PathType Leaf) { return $fullCandidate }
    return Join-Path $root 'index.html'
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    Write-Host ''
    Write-Host 'Relay is already running in another window, or port 4173 is in use.'
    Write-Host 'Close the other Relay window and double-click run.bat again.'
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 1
}

Write-Host ''
Write-Host '  Relay is open in your browser.'
Write-Host '  Keep this window open while you use the app.'
Write-Host '  Close this window when you are finished.'
Write-Host ''

Start-Process $prefix

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response
    try {
        $local = Get-LocalPath $request.Url
        $ext = [IO.Path]::GetExtension($local).ToLowerInvariant()
        $bytes = [IO.File]::ReadAllBytes($local)
        $response.StatusCode = 200
        $response.ContentType = if ($mimes.ContainsKey($ext)) { $mimes[$ext] } else { 'application/octet-stream' }
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
    } catch {
        $response.StatusCode = 404
        $msg = [Text.Encoding]::UTF8.GetBytes('Not found')
        $response.OutputStream.Write($msg, 0, $msg.Length)
    } finally {
        $response.OutputStream.Close()
    }
}
